package com.example.bbddexamen

data class Usuario(
    val id: Int,
    val nombre: String,
    val apellido: String,
    val cuenta: String,
    val dinero : String
)